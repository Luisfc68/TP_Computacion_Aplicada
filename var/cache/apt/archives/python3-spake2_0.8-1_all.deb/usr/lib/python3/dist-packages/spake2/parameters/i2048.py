from ..params import _Params
from ..groups import I2048
# Params2048 has 112-bit security and comes from NIST.
Params2048 = _Params(I2048)
