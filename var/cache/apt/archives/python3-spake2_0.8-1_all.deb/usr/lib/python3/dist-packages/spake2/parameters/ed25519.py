from ..params import _Params
from ..ed25519_group import Ed25519Group

ParamsEd25519 = _Params(Ed25519Group)
