from ._block import compress, decompress
