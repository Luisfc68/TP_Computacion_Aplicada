# Package version info, generated on install
from .version import version as __version__
VERSION = __version__

from ._version import (
    library_version_number,
    library_version_string,
)
