# This is a relay I run on a personal server. If it gets too expensive to
# run, I'll shut it down.
RENDEZVOUS_RELAY = u"ws://relay.magic-wormhole.io:4000/v1"
TRANSIT_RELAY = u"tcp:magic-wormhole-transit.debian.net:4001:priority=2.0"
